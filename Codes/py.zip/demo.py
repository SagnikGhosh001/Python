print("sagnik")
