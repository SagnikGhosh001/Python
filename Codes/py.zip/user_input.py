#a=3
#b=5
#print(a+b)
#a=5
#print(type(a))
a=int(input("Enter the value of a: "))
b=int(input("Ebter the value of b: "))
#print(a+b)
print(a/b)
print(a//b)
print(a**b)
