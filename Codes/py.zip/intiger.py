num=int(input("Enter the number: "))
if num>0:
    print("number is positive")
elif num<0:
    print("num is negetive")
else:
    print("num is zero")
