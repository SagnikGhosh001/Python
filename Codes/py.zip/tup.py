tup=(12,20,45,65)
print(tup)
