r=float(input("radius:-"))
d=2*r
c=2*3.14*r
a=3.14*r*r
print("radius {} diameter {} circumference {} area {:.2f}".format(r,d,c,a))
