a=int(input("enter the value  of a:-"))
if a>0 :
    print("this is positive")
elif a<0 :
    print("this is negative")
else :
    print("zero")

