i=1
while(i<=5):
    print(i,end='')
    i=i+1
