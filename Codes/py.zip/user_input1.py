lst=[]
n=int(input("enter no of elements:"))
for i in range(0,n):
    element=int(input("enter the element:"))
    lst.append(element)
#print(lst)
#for i in range(0,n):
  #  print(lst[i])
for values in lst:
    print(values)
