n1=0
n2=1
for a in range(1,9):
    n3=n1+n2
    print(n3)
    n1=n2
    n2=n3
