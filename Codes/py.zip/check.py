a=input("enter the value:")
if(a=='a' or a=='e' or a=='i' or a=='o' or a=='u'):
    print("a is vowe")
else:
    print("a is a consonant")
