a=int(input("value of a"))
b=int(input("value of b"))
c=2*(a+b)
print("the perimeter is",c)
