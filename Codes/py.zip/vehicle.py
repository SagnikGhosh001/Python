v=200
w=540
tw=((4*v)-w)//2
fw=200-tw
print('tw=',tw)
print('fw=',fw)
