a=int(input("please enter the value of a"))
num1=int(input("please enter the value of num1:"))
num2=int(input("please enter the value of num2:"))
if(a==1):
     d=num1+num2
     print(d)
elif(a==2):
     d=num1-num2
     print(d)
elif(a==3):
     d=num1*num2
     print(d)
elif(a>=4):
     d=num1/num2
     print(d)
